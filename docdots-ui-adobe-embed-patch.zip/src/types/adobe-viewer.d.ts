// Minimal types for Adobe PDF Embed API to keep TS quiet
export {};

declare global {
  interface Document {
    adobe_dc_view_sdk?: any;
  }
  interface Window {
    AdobeDC?: any;
    _adobeViewSDKPromise?: Promise<void>;
  }
}
