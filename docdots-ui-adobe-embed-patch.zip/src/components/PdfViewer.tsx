import React, { useEffect, useRef, useState } from "react";

/**
 * Adobe PDF Embed API based viewer
 * 
 * Props:
 *  - src: URL to the PDF (same origin as app or CORS-enabled)
 *  - page: zero-based page index to display
 *  - onPageChange: callback when user navigates in the embed viewer (zero-based)
 *
 * Requires env var: VITE_ADOBE_CLIENT_ID
 */
type Props = {
  src: string;
  page: number;
  onPageChange: (p: number) => void;
};

declare global {
  interface Window {
    AdobeDC?: any;
    _adobeViewSDKPromise?: Promise<void>;
  }
}

function loadAdobeSDK(): Promise<void> {
  if (window.AdobeDC) return Promise.resolve();
  if (window._adobeViewSDKPromise) return window._adobeViewSDKPromise;
  window._adobeViewSDKPromise = new Promise<void>((resolve) => {
    const script = document.createElement("script");
    script.src = "https://acrobatservices.adobe.com/view-sdk/viewer.js";
    script.async = true;
    script.onload = () => {
      if ((document as any).adobe_dc_view_sdk) {
        // Preferred hook fired by the SDK itself
        document.addEventListener("adobe_dc_view_sdk.ready", () => resolve(), { once: true });
      } else {
        // Fallback: SDK already ready
        resolve();
      }
    };
    document.body.appendChild(script);
  });
  return window._adobeViewSDKPromise;
}

export default function PdfViewer({ src, page, onPageChange }: Props) {
  const [error, setError] = useState<string | null>(null);
  const viewerRef = useRef<any>(null);
  const apisRef = useRef<any>(null);
  const containerId = "adobe-viewer";

  // Initialize viewer when SDK + src ready
  useEffect(() => {
    let cancelled = false;
    setError(null);

    if (!src) return;

    loadAdobeSDK().then(async () => {
      if (cancelled) return;

      const clientId = import.meta.env.VITE_ADOBE_CLIENT_ID as string;
      if (!clientId) {
        setError("Missing VITE_ADOBE_CLIENT_ID in your environment.");
        return;
      }

      // Reset container content if reusing
      const host = document.getElementById(containerId);
      if (host) host.innerHTML = "";

      const view = new window.AdobeDC.View({
        clientId,
        divId: containerId,
      });
      viewerRef.current = view;

      const fileName = decodeURIComponent(src.split("/").pop() || "document.pdf");

      view.previewFile(
        {
          content: { location: { url: src } },
          metaData: { fileName },
        },
        {
          embedMode: "SIZED_CONTAINER",
          showDownloadPDF: true,
          showPrintPDF: true,
          defaultViewMode: "FIT_PAGE",
        }
      );

      // Wire up APIs
      view.getAPIs().then((apis: any) => {
        apisRef.current = apis;

        // Sync external state -> viewer
        if (typeof page === "number" && page >= 0) {
          // API is 1-based
          apis.gotoLocation(page + 1).catch(() => {});
        }

        // Viewer -> external state
        apis.on("PAGE_VIEW_CHANGE", (e: any) => {
          if (e && typeof e.pageNumber === "number") {
            onPageChange(Math.max(0, e.pageNumber - 1));
          }
        });
      });
    }).catch((e) => {
      setError(String(e));
    });

    return () => {
      cancelled = true;
    };
  }, [src]); // re-init if file changes

  // Respond to external page changes after init
  useEffect(() => {
    if (apisRef.current && typeof page === "number" && page >= 0) {
      apisRef.current.gotoLocation(page + 1).catch(() => {});
    }
  }, [page]);

  return (
    <div className="bg-white rounded-xl border border-slate-200 overflow-hidden">
      <div className="flex items-center justify-between px-4 py-2 border-b border-slate-200">
        <div className="text-sm text-slate-700">Adobe PDF preview</div>
        <div className="text-xs text-slate-500">Client: {import.meta.env.VITE_ADOBE_CLIENT_ID ? "configured" : "not set"}</div>
      </div>

      {error ? (
        <div className="p-8 text-sm text-red-600">{error}</div>
      ) : (
        <div id={containerId} className="h-[75vh] w-full bg-slate-50" />
      )}
    </div>
  );
}
